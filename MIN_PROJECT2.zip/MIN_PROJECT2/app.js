const prevButton = document.querySelector(".prev");
const nextButton = document.querySelector(".next");
const images = document.querySelector(".images");

//initial index
let idx = 0;
const imageWidth = 170;

//setting button for next
nextButton.addEventListener("click",()=>{
    if(idx < images.children.length - 8)       //length is 10 since total image is 10 each having length 1
    {
        idx++;
        images.style.transform = `translateX(-${idx * imageWidth}px)`;  //{-(1 * 170)px};
    }
});

prevButton.addEventListener("click",()=>{
    if(idx > 0)
    {
        idx--;
        images.style.transform = `translateX(-${idx * imageWidth}px)`;
    }
});