let gameSeq = [];
let userSeq = [];

let btns = ["yellow","red","purple","green"];

let started = false;
let level = 0;

let h2 = document.querySelector("h2");

document.addEventListener("keypress",function()
{
    if(started == false)
    {
        console.log("game is started");
        started = true;

        levelUp();
    }
});

function btnFlash(btn) {
    console.log("Flashing button:", btn.id); // Debugging log
    btn.classList.add("flash");
 
    setTimeout(function() {
        btn.classList.remove("flash");
    }, 250); // Slightly longer duration for better visibility
}


function levelUp()
{
    userSeq =[];
    level++;
    h2.innerText = `level ${level}`;

    //random btn flash

    let randomIDX = Math.floor(Math.random() * 3);
    let randomColor = btns[randomIDX];
    let randombtn = document.querySelector(`#${randomColor}`);  //most imp part sala 
    
    // console.log(randomIDX);
    // console.log(randomColor);
    // console.log(randombtn);

    gameSeq.push(randomColor);
    console.log(gameSeq);
    
    btnFlash(randombtn);
}

function checkAns(idx)
{
    // console.log(`current level : ${level}`);
    if(userSeq[idx] == gameSeq[idx])
    {
        if(userSeq.length == gameSeq.length)
        {
            setTimeout(levelUp,1000);       
        }
    }
    else 
    {
        h2.innerHTML = `Game over. Your Score was <b>${level}</b> <br>Press any Key to start !!!`;

        document.querySelector("body").style.backgroundColor = "red";
        setTimeout(function()
        {
            document.querySelector("body").style.backgroundColor = "white";
        }, 150);
        
        reset();
    }
}

function btnPress()
{
    console.log(this);
    let btn = this;
    btnFlash(btn);

    userColor = btn.getAttribute("id");
    userSeq.push(userColor);

    checkAns(userSeq.length-1);
}

let allBtns = document.querySelectorAll(".btn");

for(btn of allBtns)
{
    btn.addEventListener("click",btnPress);
}

function reset()
{
    started = false;
    gameSeq = [];
    userSeq = [];
    level = 0;
}